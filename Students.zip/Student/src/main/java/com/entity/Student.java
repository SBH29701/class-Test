package com.entity;

public class Student {
	private int id;
	private String name;
	private int age;
	private String yop;
	private String mobile;
	
	public Student() {
		super();
	}
	
	public Student(String name, String yop, int age, String mobile) {
		super();
		this.name = name;
		this.yop = yop;
		this.age = age;
		this.mobile = mobile;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getYop() {
		return yop;
	}

	public void setYop(String yop) {
		this.yop = yop;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	
	
}

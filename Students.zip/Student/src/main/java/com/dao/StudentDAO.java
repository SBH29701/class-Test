package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.entity.Student;

public class StudentDAO {
	private Connection conn;

	public StudentDAO(Connection conn) {
		super();
		this.conn = conn;
	}
	
	public boolean addStudent(Student s) {
		boolean f = false;
		try {
			String sql = "INSERT INTO student_details(name, age, yop, mobile) VALUES(?, ?, ?, ?)";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, s.getName());
			ps.setInt(2, s.getAge());
			ps.setString(3, s.getYop());
			ps.setString(4, s.getMobile());
			
			int i = ps.executeUpdate();
			if (i == 1) {
				f = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return f;
	} 
	
	public List<Student> getAllStudent(){
		List<Student> list = new ArrayList();
		Student student = null;
		
		try {
			String sql = "select * from student_details ORDER BY id";
			PreparedStatement ps = conn.prepareStatement(sql);
			
			ResultSet rs = ps.executeQuery();
			
			while (rs.next()) {
				student = new Student();
				student.setId(rs.getInt(1));
				student.setName(rs.getString(2));
				student.setAge(rs.getInt(3));
				student.setYop(rs.getString(4));
				student.setMobile(rs.getString(5));
				list.add(student);
			}	
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public Student getStudentById(int id) {
		Student s = null;
		try {
			String sql = "SELECT * FROM student_details WHERE id=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			
			while (rs.next()) {
				s = new Student();
				s.setId(rs.getInt(1));
				s.setName(rs.getString(2));
				s.setAge(rs.getInt(3));
				s.setYop(rs.getString(4));
				s.setMobile(rs.getString(5));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return s;
	}
	
	public boolean updateStudent(Student s) {
		boolean f = false;
		try {
			String sql = "update student_details set title = ?, description = ?, category = ?, status = ?, location = ? WHERE id = ?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, s.getName());
			ps.setInt(2, s.getAge());
			ps.setString(3, s.getYop());
			ps.setString(4, s.getMobile());
			ps.setInt(5, s.getId());
			
			int i = ps.executeUpdate();
			
			if (i == 1) {
				f = true;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return f;
	}
	
	public boolean deleteStudent(int id) {
		boolean f = false;
		try {
			String sql = "delete from student_details where id = ?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, id);
			
			int i = ps.executeUpdate();
			if (i == 1) {
				f = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return f;
	}
}

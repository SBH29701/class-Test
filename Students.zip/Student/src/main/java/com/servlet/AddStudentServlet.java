package com.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DB.DBConnect;
import com.dao.StudentDAO;
import com.entity.Student;

@WebServlet("/addStudent")
public class AddStudentServlet extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			String name = req.getParameter("name");
			String yop = req.getParameter("yop");
			int age = Integer.parseInt(req.getParameter("age"));
			String mobile = req.getParameter("mobile");
			
			Student s = new Student();
			s.setName(name);
			s.setAge(age);
			s.setYop(yop);
			s.setMobile(mobile);
			
			HttpSession session = req.getSession();
			
			StudentDAO dao = new StudentDAO(DBConnect.getCon());
			boolean f = dao.addStudent(s);
			if (f) {
				session.setAttribute("succMsg", "Student add successfully");
				resp.sendRedirect("addStudent.jsp");
			}else {
				session.setAttribute("errorMsg", "Student add successfully");
				resp.sendRedirect("addStudent.jsp");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

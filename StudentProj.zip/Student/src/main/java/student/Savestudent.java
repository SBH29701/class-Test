package student;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;


public class Savestudent {
	public static void main(String[] args){
		
	Student s= new Student();
	s.setName("sahoo");
	s.setId(109);
	s.setYop(2020);
	s.setAge("21");
	s.setPhone(909077111);
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("hb");
    EntityManager em= emf.createEntityManager();
    EntityTransaction et= em.getTransaction();
    et.begin();
    em.persist(s);
    et.commit();
    
    System.out.println("Data saved successfully");
    
}
}


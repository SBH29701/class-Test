package student;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;


public class Updatestudent {

	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory= Persistence.createEntityManagerFactory("hb");
		EntityManager entityManager= entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction= entityManager.getTransaction();
				entityTransaction.begin();
				Student student = entityManager.find(Student.class, 103);
				student.setName("bhusan");
				student.setId(101);
				student.setAge("23");
				student.setYop(2002);
				student.setPhone(123456789);
				entityManager.merge(student);
				entityTransaction.commit();
				

	}

}

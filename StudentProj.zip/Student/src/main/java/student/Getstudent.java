package student;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;


public class Getstudent {

	public static void main(String[] args) {
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("hb");
				EntityManager em= emf.createEntityManager();
				EntityTransaction et= em.getTransaction();
		et.begin();
		Student student = em.find(Student.class, 103);
		if(student!= null) {
			System.out.println(student.getId());
			System.out.println(student.getName());
			System.out.println(student.getYop());
			System.out.println(student.getAge());
			
		}else {
			System.out.println("There is no Data");
		}
		et.commit();

	}

}
